//
//  ViewController.swift
//  Feelr
//
//  Created by Lucas Atayde on 12/1/18.
//  Copyright © 2018 Lucas Atayde. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {


    @IBOutlet weak var main_text: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        main_text.delegate = self
    }
    
    @IBAction func send_to_feelr(_ sender: Any) {
        
        let message = main_text.text!
        let formatted = message.replacingOccurrences(of: " ", with: "_")
        
        let feelr_url = URL(string:"https://c9495c5c.ngrok.io/message/" + formatted)!
        let task = URLSession.shared.dataTask(with: feelr_url) { data, response, error in
            if let error = error {
                return
            }
            guard let httpResponse = response as? HTTPURLResponse,
                (200...299).contains(httpResponse.statusCode) else {
                    return
            }
        }
        
        task.resume()
        
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        main_text.resignFirstResponder()
        return true
    }
}

